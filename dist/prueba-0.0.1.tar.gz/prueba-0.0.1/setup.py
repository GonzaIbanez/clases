from setuptools import setup    

setup(
    author="GonzaloIbañez",
    author_email="gonzalototi551@gmail.com",
    description="Segunda preentrega del curso",
    version="0.0.1",
    name="prueba",
    packages=['Paquete_entrega']
)